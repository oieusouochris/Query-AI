
import React, { useState, useEffect, useRef, useCallback } from 'react';
import QueryCanvas from './components/QueryCanvas';
import QueryGallery from './components/QueryGallery';
import Sidebar from './components/Sidebar';
import { QueryRecord, ChatHistoryItem, AIResponse, Message } from './types';
// Added ICONS import to fix the "Cannot find name 'ICONS'" error
import { ICONS } from './constants';

// Chaves consistentes para o LocalStorage
const STORAGE_KEYS = {
  QUERIES: 'query_master_queries_v1',
  CHATS: 'query_master_chats_v1',
  SIDEBAR: 'query_master_sidebar_v1'
};

const storage = {
  get: <T,>(key: string, defaultValue: T): T => {
    try {
      const item = localStorage.getItem(key);
      if (!item) return defaultValue;
      return JSON.parse(item);
    } catch (e) {
      console.error(`Erro ao ler ${key}:`, e);
      return defaultValue;
    }
  },
  set: (key: string, value: any) => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.error(`Erro ao gravar ${key}:`, e);
    }
  }
};

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('Chat');
  const [isSidebarPinned, setIsSidebarPinned] = useState(() => storage.get(STORAGE_KEYS.SIDEBAR, false));
  
  // Estados inicializados diretamente do storage para garantir persistência imediata
  const [queries, setQueries] = useState<QueryRecord[]>(() => storage.get(STORAGE_KEYS.QUERIES, []));
  const [chatHistory, setChatHistory] = useState<ChatHistoryItem[]>(() => storage.get(STORAGE_KEYS.CHATS, []));
  const [selectedChat, setSelectedChat] = useState<ChatHistoryItem | null>(null);

  // Efeitos de Persistência Global: Sincroniza estados com localStorage sempre que mudarem
  useEffect(() => {
    storage.set(STORAGE_KEYS.QUERIES, queries);
  }, [queries]);

  useEffect(() => {
    storage.set(STORAGE_KEYS.CHATS, chatHistory);
  }, [chatHistory]);

  useEffect(() => {
    storage.set(STORAGE_KEYS.SIDEBAR, isSidebarPinned);
  }, [isSidebarPinned]);

  const gliderRef = useRef<HTMLSpanElement>(null);
  const chatTabRef = useRef<HTMLLabelElement>(null);
  const galleryTabRef = useRef<HTMLLabelElement>(null);

  useEffect(() => {
    const activeRef = activeTab === 'Chat' ? chatTabRef.current : galleryTabRef.current;
    if (activeRef && gliderRef.current) {
      gliderRef.current.style.width = `${activeRef.offsetWidth}px`;
      gliderRef.current.style.left = `${activeRef.offsetLeft}px`;
      gliderRef.current.style.backgroundColor = activeTab === 'Chat' ? '#0A4EE4' : '#E64E36';
    }
  }, [activeTab]);

  const handleSaveQuery = useCallback((newQuery: QueryRecord) => {
    setQueries(prev => {
      const exists = prev.find(q => q.id === newQuery.id);
      if (exists) return prev.map(q => q.id === newQuery.id ? newQuery : q);
      return [newQuery, ...prev];
    });
  }, []);

  const handleUpdateQuery = useCallback((updated: QueryRecord) => {
    setQueries(prev => prev.map(q => q.id === updated.id ? updated : q));
  }, []);

  const handleDeleteQuery = useCallback((id: string) => {
    if (window.confirm('Excluir esta query da galeria?')) {
      setQueries(prev => prev.filter(q => q.id !== id));
    }
  }, []);
  
  const handleCloneQuery = useCallback((query: QueryRecord) => {
    const cloned: QueryRecord = { 
      ...query, 
      id: `clone-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`, 
      title: `${query.title} (Cópia)`, 
      createdAt: new Date().toISOString() 
    };
    setQueries(prev => [cloned, ...prev]);
  }, []);

  const handleEditInChat = useCallback((query: QueryRecord) => {
    const pseudoChat: ChatHistoryItem = {
      id: `edit-${query.id}`,
      prompt: `Editando: ${query.title}`,
      response: {
        title: query.title,
        description: query.description,
        code: query.code,
        category: query.category,
        language: query.language
      },
      messages: [
        { id: 'm1', role: 'user', content: `Quero editar "${query.title}"` },
        { id: 'm2', role: 'assistant', content: `Pronto! Carreguei o código no canvas. O que deseja mudar?`, query: { ...query } }
      ],
      timestamp: new Date().toISOString()
    };
    setSelectedChat(pseudoChat);
    setActiveTab('Chat');
  }, []);

  const handleChatUpdated = useCallback((chatId: string | null, prompt: string, response: AIResponse, allMessages: Message[]) => {
    const newChatId = chatId || `chat-${Date.now()}`;
    
    const updatedChat: ChatHistoryItem = {
      id: newChatId,
      prompt,
      response,
      messages: allMessages,
      timestamp: new Date().toISOString()
    };

    setChatHistory(prev => {
      const existingIdx = prev.findIndex(c => c.id === chatId);
      if (existingIdx > -1 && chatId) {
        const updatedList = [...prev];
        updatedList[existingIdx] = updatedChat;
        return updatedList;
      } else {
        return [updatedChat, ...prev];
      }
    });

    setSelectedChat(updatedChat);
  }, []);

  const handleStartNewChat = useCallback(() => {
    setSelectedChat(null);
    setActiveTab('Chat');
  }, []);

  const handleClearHistory = useCallback(() => {
    if (window.confirm('Limpar todo o histórico de chats?')) {
      setChatHistory([]);
      setSelectedChat(null);
    }
  }, []);

  const handleDeleteHistoryItem = useCallback((id: string) => {
    setChatHistory(prev => prev.filter(item => item.id !== id));
    if (selectedChat?.id === id) setSelectedChat(null);
  }, [selectedChat]);

  return (
    <div className="flex h-screen bg-brand-bege text-brand-azulEscuro overflow-hidden">
      <Sidebar 
        history={chatHistory} 
        onSelectItem={(item) => { setSelectedChat(item); setActiveTab('Chat'); }}
        onClearHistory={handleClearHistory}
        onNewChat={handleStartNewChat}
        onDeleteItem={handleDeleteHistoryItem}
        isPinned={isSidebarPinned}
        onTogglePin={() => setIsSidebarPinned(!isSidebarPinned)}
      />

      <div 
        className="flex-1 flex flex-col h-full relative transition-all duration-700 ease-in-out"
        style={{ paddingLeft: isSidebarPinned ? '356px' : '96px' }}
      >
        <header className="sticky top-0 z-[100] w-full px-12 py-8 flex items-center bg-brand-bege/80 backdrop-blur-md">
          <div className="flex items-center gap-4 w-1/4">
            <div className="w-11 h-11 bg-brand-azul rounded-2xl flex items-center justify-center text-white font-black text-xl shadow-xl shadow-brand-azul/20">Q</div>
            <h1 className="hidden lg:block text-brand-azulEscuro font-black text-2xl tracking-tighter">Query AI</h1>
          </div>

          <div className="flex flex-1 justify-center">
            <div className="tabs-container">
              <input type="radio" id="radio-nav-1" checked={activeTab === 'Chat'} onChange={() => setActiveTab('Chat')} />
              <label ref={chatTabRef} className="tab-label" htmlFor="radio-nav-1">Chat</label>
              <input type="radio" id="radio-nav-2" checked={activeTab === 'Coleções'} onChange={() => setActiveTab('Coleções')} />
              <label ref={galleryTabRef} className="tab-label" htmlFor="radio-nav-2">Galeria</label>
              <span ref={gliderRef} className="glider"></span>
            </div>
          </div>
          
          <div className="w-1/4 flex justify-end">
            {/* Global search removed as requested to keep only the contextual gallery search visible */}
          </div>
        </header>

        <main className="flex-1 overflow-visible relative">
          <div 
            className={`absolute inset-0 px-12 pt-8 pb-0 transition-all duration-500 ease-in-out flex flex-col overflow-visible ${
              activeTab === 'Chat' ? 'opacity-100 translate-y-0 visible z-10 pointer-events-auto' : 'opacity-0 translate-y-10 invisible z-0 pointer-events-none'
            }`}
          >
            <QueryCanvas 
              onSave={handleSaveQuery} 
              initialChat={selectedChat}
              onChatUpdated={handleChatUpdated}
            />
          </div>
          
          <div 
            className={`absolute inset-0 px-12 pt-8 pb-0 transition-all duration-500 ease-in-out flex flex-col overflow-visible ${
              activeTab === 'Coleções' ? 'opacity-100 translate-y-0 visible z-10 pointer-events-auto' : 'opacity-0 translate-y-10 invisible z-0 pointer-events-none'
            }`}
          >
            <div className="h-full overflow-y-auto custom-scrollbar pr-4">
               <QueryGallery 
                  queries={queries} 
                  onClone={handleCloneQuery} 
                  onUpdate={handleUpdateQuery} 
                  onDelete={handleDeleteQuery} 
                  onEditInChat={handleEditInChat}
               />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;
