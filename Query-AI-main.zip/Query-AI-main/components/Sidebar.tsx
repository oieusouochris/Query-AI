
import React, { useState, useMemo } from 'react';
import { ChatHistoryItem } from '../types';
import { ICONS } from '../constants';

interface SidebarProps {
  history: ChatHistoryItem[];
  onSelectItem: (item: ChatHistoryItem) => void;
  onClearHistory: () => void;
  onNewChat: () => void;
  isPinned: boolean;
  onTogglePin: () => void;
  onDeleteItem?: (id: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ history, onSelectItem, onClearHistory, onNewChat, isPinned, onTogglePin, onDeleteItem }) => {
  const [isHovered, setIsHovered] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [pinnedWidth, setPinnedWidth] = useState<'open' | 'closed'>('open');

  const handleTogglePin = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isPinned) {
      setPinnedWidth(isHovered ? 'open' : 'closed');
    }
    onTogglePin();
  };

  const isExpanded = isPinned ? (pinnedWidth === 'open') : isHovered;

  const filteredHistory = useMemo(() => {
    if (!searchTerm) return history;
    const lowerSearch = searchTerm.toLowerCase();
    return history.filter(item => 
      item.response.title.toLowerCase().includes(lowerSearch) || 
      item.prompt.toLowerCase().includes(lowerSearch)
    );
  }, [history, searchTerm]);

  // Function to get short title as requested (first two words)
  const getShortTitle = (title: string) => {
    const words = title.split(' ');
    if (words.length <= 2) return title.toUpperCase();
    return (words[0] + ' ' + words[1]).toUpperCase();
  };

  return (
    <aside 
      onMouseEnter={() => !isPinned && setIsHovered(true)}
      onMouseLeave={() => !isPinned && setIsHovered(false)}
      className={`fixed left-4 top-1/2 -translate-y-1/2 z-[200] transition-all duration-700 h-[92vh] bg-white shadow-[0_20px_60px_-15px_rgba(0,0,0,0.1)] border border-brand-azulEscuro/5 flex flex-col overflow-hidden select-none translate-z-0 backface-hidden`}
      style={{
        width: isExpanded ? '320px' : '72px',
        borderRadius: isExpanded ? '40px' : '100px',
        transitionTimingFunction: 'cubic-bezier(0.34, 1.56, 0.64, 1)'
      }}
    >
      <div className={`p-4 flex flex-col items-center ${isExpanded ? 'pt-8 pb-4' : 'pt-6 pb-6'}`}>
        
        {!isExpanded && (
          <button 
            onClick={onNewChat}
            className="w-12 h-12 bg-brand-azul hover:bg-brand-azulEscuro text-white rounded-full flex items-center justify-center transition-all duration-300 shadow-lg shadow-brand-azul/30 active:scale-95"
          >
            <ICONS.Plus className="w-6 h-6" />
          </button>
        )}

        {isExpanded && (
          <div className="w-full animate-in fade-in duration-500">
            <div className="flex items-center justify-between mb-8 px-2">
              <button 
                onClick={(e) => { e.stopPropagation(); onClearHistory(); }}
                className="w-10 h-10 rounded-full bg-brand-bege flex items-center justify-center text-brand-azulEscuro/40 hover:text-brand-coral hover:bg-brand-coral/10 transition-colors"
                title="Limpar Histórico"
              >
                 <ICONS.Trash className="w-5 h-5" />
              </button>
              
              <button 
                onClick={handleTogglePin}
                className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${isPinned ? 'bg-brand-azul text-white shadow-md shadow-brand-azul/20' : 'bg-brand-bege text-brand-azulEscuro/40 hover:text-brand-azul'}`}
              >
                <ICONS.Pin className={`w-5 h-5 ${isPinned ? 'rotate-45' : ''}`} />
              </button>
            </div>

            <button 
              onClick={onNewChat}
              className="bg-brand-azul hover:bg-brand-azulEscuro text-white rounded-2xl flex items-center justify-center transition-all duration-300 shadow-lg shadow-brand-azul/30 active:scale-95 group w-full py-4 gap-2 text-[11px] font-black uppercase tracking-widest mb-8"
            >
              <ICONS.Plus className="w-5 h-5" />
              <span>NOVO CHAT</span>
            </button>
            
            <div className="px-1 mb-8">
              <div className="relative">
                <ICONS.Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-brand-azulEscuro/20" />
                <input 
                  type="text" 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Buscar no histórico..."
                  className="w-full bg-brand-bege/50 border border-brand-azulEscuro/20 rounded-full py-3.5 pl-11 pr-4 text-[11px] font-bold outline-none focus:border-brand-azul/40 focus:bg-white transition-all placeholder:text-brand-azulEscuro/30"
                />
              </div>
            </div>

            <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-brand-azulEscuro/20 mb-4 px-4">ATIVIDADE RECENTE</h3>
          </div>
        )}
      </div>

      <div className="flex-1 overflow-y-auto px-0 py-2 custom-scrollbar overflow-x-hidden">
        {filteredHistory.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-40 opacity-20">
            {isExpanded && <p className="text-[10px] font-black">SEM HISTÓRICO</p>}
          </div>
        ) : (
          <div className={`space-y-1 ${isExpanded ? 'px-4' : 'px-0 flex flex-col items-center'}`}>
            {filteredHistory.map((item) => (
              <div key={item.id} className="relative group/item w-full px-1 py-1">
                <div className={`flex items-center gap-1 ${isExpanded ? 'flex-row' : 'flex-col'}`}>
                  <button
                    onClick={() => onSelectItem(item)}
                    className={`flex-1 transition-all duration-200 flex items-center ${
                      isExpanded 
                      ? 'p-3 rounded-2xl hover:bg-brand-bege/50' 
                      : 'w-12 h-12 justify-center rounded-full hover:bg-brand-bege/80'
                    }`}
                  >
                    <div className={`flex items-center ${isExpanded ? 'gap-3 w-full overflow-hidden' : 'justify-center shrink-0'}`}>
                      <div className={`shrink-0 flex items-center justify-center rounded-xl transition-all ${
                        isExpanded ? 'w-9 h-9 bg-brand-bege group-hover/item:bg-white' : 'w-10 h-10 bg-brand-bege/40'
                      }`}>
                        <ICONS.Chat className={`text-brand-azulEscuro/40 group-hover/item:text-brand-azul w-4 h-4 transition-colors`} />
                      </div>
                      {isExpanded && (
                        <div className="flex-1 text-left min-w-0">
                          <p className="text-[11px] font-black text-brand-azulEscuro leading-tight truncate uppercase tracking-tight">
                            {getShortTitle(item.response.title)}
                          </p>
                          <p className="text-[9px] font-medium text-brand-azulEscuro/30 truncate mt-0.5">
                            {item.prompt}
                          </p>
                        </div>
                      )}
                    </div>
                  </button>
                  
                  {isExpanded && (
                    <div className="flex flex-col gap-1 pr-1">
                       <button 
                        onClick={(e) => { e.stopPropagation(); onDeleteItem?.(item.id); }}
                        className="p-1.5 text-brand-azulEscuro/30 hover:text-brand-coral transition-colors"
                        title="Deletar Chat"
                      >
                        <ICONS.Trash className="w-3.5 h-3.5" />
                      </button>
                      <button 
                        className="p-1.5 text-brand-azulEscuro/30 hover:text-brand-azul transition-colors"
                        title="Fixar Chat"
                      >
                        <ICONS.Pin className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </aside>
  );
};

export default Sidebar;
