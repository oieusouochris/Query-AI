
import React, { useState, useMemo, useEffect, useCallback, useRef } from 'react';
import { generateQuery } from '../services/gemini';
import { AIResponse, Category, QueryRecord, ChatHistoryItem, Message } from '../types';
import { ICONS } from '../constants';

interface QueryCanvasProps {
  onSave: (query: QueryRecord) => void;
  initialChat?: ChatHistoryItem | null;
  onChatUpdated?: (chatId: string | null, prompt: string, response: AIResponse, allMessages: Message[]) => void;
}

const StarSVG = ({ className }: { className: string }) => (
  <svg className={className} viewBox="0 0 122.88 122.88">
    <path fill="#fffdef" d="M61.44,0L76.1,41.41L122.88,61.44L76.1,81.47L61.44,122.88L46.78,81.47L0,61.44L46.78,41.41L61.44,0L61.44,0Z" />
  </svg>
);

const LoaderCriando = () => (
  <div className="flex flex-col items-center justify-center p-20 animate-in fade-in zoom-in duration-500 min-h-[300px]">
    <div className="gooey-loader scale-75">
      <div className="gooey-dot gooey-dot-1"></div>
      <div className="gooey-dot gooey-dot-2"></div>
      <div className="gooey-dot gooey-dot-3"></div>
    </div>
    <p className="mt-8 text-brand-azulEscuro/40 font-black uppercase tracking-[0.3em] text-[10px] animate-pulse">Arquitetando Query Robusta...</p>
  </div>
);

const QueryCanvas: React.FC<QueryCanvasProps> = ({ onSave, initialChat, onChatUpdated }) => {
  const [prompt, setPrompt] = useState('');
  const [inputTitle, setInputTitle] = useState('');
  const [inputDescription, setInputDescription] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [currentQuery, setCurrentQuery] = useState<AIResponse | null>(null);
  const [editedCode, setEditedCode] = useState('');
  const [editedTitle, setEditedTitle] = useState('');
  const [editedDescription, setEditedDescription] = useState('');
  const [copyFeedback, setCopyFeedback] = useState(false);
  const [saveFeedback, setSaveFeedback] = useState(false);
  const [isCanvasOpen, setIsCanvasOpen] = useState(false);
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [isEditingDesc, setIsEditingDesc] = useState(false);
  
  const [history, setHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);

  // Estados para o Microfone
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<any>(null);
  
  const chatEndRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = useCallback(() => {
    if (chatEndRef.current && chatContainerRef.current) {
      chatContainerRef.current.scrollTo({
        top: chatContainerRef.current.scrollHeight,
        behavior: 'smooth'
      });
    }
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading, scrollToBottom]);

  useEffect(() => {
    if (initialChat) {
      setActiveChatId(initialChat.id);
      setMessages(initialChat.messages || []);
      setCurrentQuery(initialChat.response);
      setEditedCode(initialChat.response.code);
      setEditedTitle(initialChat.response.title);
      setEditedDescription(initialChat.response.description);
      setHistory([initialChat.response.code]);
      setHistoryIndex(0);
      setIsCanvasOpen(true);
      setIsEditingTitle(false);
      setIsEditingDesc(false);
    } else {
      setActiveChatId(null);
      setMessages([]);
      setCurrentQuery(null);
      setIsCanvasOpen(false);
    }
  }, [initialChat]);

  // Inicialização do Reconhecimento de Voz
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = 'pt-BR';

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setPrompt(prev => (prev ? `${prev} ${transcript}` : transcript));
        setIsListening(false);
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error('Erro no reconhecimento:', event.error);
        setIsListening(false);
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }
  }, []);

  const toggleListening = () => {
    if (!recognitionRef.current) {
      alert("Seu navegador não suporta reconhecimento de voz.");
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      try {
        recognitionRef.current.start();
        setIsListening(true);
      } catch (e) {
        console.error("Falha ao iniciar reconhecimento:", e);
      }
    }
  };

  const addToHistory = useCallback((newCode: string) => {
    if (history[historyIndex] === newCode) return;
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(newCode);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
  }, [history, historyIndex]);

  const handleUndo = () => historyIndex > 0 && (setHistoryIndex(historyIndex - 1), setEditedCode(history[historyIndex - 1]));
  const handleRedo = () => historyIndex < history.length - 1 && (setHistoryIndex(historyIndex + 1), setEditedCode(history[historyIndex + 1]));

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    
    const userMsg: Message = { id: `user-${Date.now()}`, role: 'user', content: prompt };
    const updatedMessages: Message[] = [...messages, userMsg];
    setMessages(updatedMessages);
    const lastPrompt = prompt;
    setPrompt('');
    setIsLoading(true);

    try {
      const contextPrompt = `${inputTitle ? `Projeto: ${inputTitle}. ` : ''}${inputDescription ? `Contexto Técnico: ${inputDescription}. ` : ''}Necessidade: ${lastPrompt}`;
      const result = await generateQuery(contextPrompt);
      
      const assistantMsg: Message = { 
        id: `assistant-${Date.now()}`, 
        role: 'assistant', 
        content: `A estrutura para "${result.title}" foi finalizada com foco em performance e robustez. Analise o código no Canvas ao lado.`,
        query: result 
      };

      const finalMessages = [...updatedMessages, assistantMsg];
      setMessages(finalMessages);
      setCurrentQuery(result);
      setEditedCode(result.code);
      setEditedTitle(result.title);
      setEditedDescription(result.description);
      setHistory([result.code]);
      setHistoryIndex(0);
      setIsCanvasOpen(true);
      setIsEditingTitle(false);
      setIsEditingDesc(false);
      
      onChatUpdated?.(activeChatId, lastPrompt, result, finalMessages);
    } catch (err: any) {
      const errorMessage = err.message || "Não foi possível processar sua solicitação no momento.";
      setMessages(prev => [...prev, { 
        id: `err-${Date.now()}`, 
        role: 'assistant', 
        content: `⚠️ Erro de Arquitetura: ${errorMessage}. Tente fornecer mais detalhes sobre suas tabelas ou objetivo.` 
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = () => {
    if (!currentQuery) return;
    setSaveFeedback(true);
    onSave({
      id: `query-${Date.now()}`,
      title: editedTitle || currentQuery.title,
      description: editedDescription || currentQuery.description,
      code: editedCode,
      category: currentQuery.category as unknown as Category,
      createdAt: new Date().toISOString(),
      language: currentQuery.language
    });
    setTimeout(() => {
      setSaveFeedback(false);
      setIsCanvasOpen(false);
    }, 1500);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(editedCode);
    setCopyFeedback(true);
    setTimeout(() => setCopyFeedback(false), 2000);
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour >= 5 && hour < 12) return "Bom dia";
    if (hour >= 12 && hour < 18) return "Boa tarde";
    return "Boa noite";
  };

  const handleCanvasView = (q: AIResponse) => {
    setCurrentQuery(q);
    setEditedCode(q.code);
    setEditedTitle(q.title);
    setEditedDescription(q.description);
    setIsCanvasOpen(true);
    setIsEditingTitle(false);
    setIsEditingDesc(false);
  };

  return (
    <div className="flex w-full h-full gap-6 overflow-visible translate-z-0">
      
      <div className={`flex flex-col transition-all duration-700 ease-[cubic-bezier(0.34,1.56,0.64,1)] h-full overflow-visible ${isCanvasOpen ? 'w-1/2' : 'w-full max-w-5xl mx-auto'}`}>
        
        {messages.length === 0 && !isLoading && (
          <div className="mb-12 text-left mt-4 w-full px-4 animate-in fade-in slide-in-from-top-6 duration-1000">
            <h2 className="text-7xl font-black tracking-tighter mb-5 bg-gradient-to-r from-brand-azul via-brand-coral to-brand-amarelo bg-clip-text text-transparent">
              {getGreeting()}, Cientista!
            </h2>
            <p className="text-brand-azulEscuro font-bold text-2xl opacity-80">Solicite sua query robusta para produção.</p>
          </div>
        )}

        <div 
          ref={chatContainerRef}
          className="flex-1 overflow-y-auto px-4 py-8 space-y-10 custom-scrollbar scroll-smooth"
        >
          {messages.map((msg) => (
            <div key={msg.id} className={`flex items-start gap-5 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'} animate-in fade-in slide-in-from-bottom-4 duration-500`}>
              <div className={`shrink-0 w-14 h-14 rounded-[1.25rem] flex items-center justify-center shadow-xl border-4 border-white/50 transition-all hover:scale-110 hover:rotate-3 ${
                msg.role === 'user' ? 'bg-gradient-to-br from-brand-azul to-brand-azulEscuro text-white' : 'bg-gradient-to-br from-brand-azulEscuro to-black text-white'
              }`}>
                {msg.role === 'user' ? <ICONS.User className="w-7 h-7" /> : <ICONS.Bot className="w-7 h-7" />}
              </div>

              <div className={`max-w-[80%] px-8 py-6 rounded-[2.5rem] shadow-sm relative transition-all hover:shadow-xl ${
                msg.role === 'user' 
                ? 'bg-brand-azul text-white rounded-tr-none font-medium' 
                : msg.content.includes('⚠️') 
                  ? 'bg-brand-coral/10 border-2 border-brand-coral/30 text-brand-coral rounded-tl-none font-bold'
                  : 'bg-white border border-brand-azulEscuro/5 text-brand-azulEscuro rounded-tl-none font-semibold'
              }`}>
                <p className="text-base leading-relaxed">{msg.content}</p>
                {msg.query && (
                  <button 
                    onClick={() => handleCanvasView(msg.query!)}
                    className="mt-6 flex items-center gap-3 text-[11px] uppercase font-black tracking-widest bg-brand-azul text-white hover:bg-brand-azulEscuro p-5 px-9 rounded-3xl transition-all shadow-xl shadow-brand-azul/30 border-2 border-white/10 active:scale-95 group"
                  >
                    <ICONS.Dashboard className="w-5 h-5 transition-transform group-hover:rotate-12" /> ABRIR CANVAS DE CÓDIGO
                  </button>
                )}
              </div>
            </div>
          ))}
          {isLoading && <LoaderCriando />}
          <div ref={chatEndRef} className="h-4" />
        </div>

        <div className="pb-12 pt-6 px-4 bg-transparent mt-auto overflow-visible relative z-20">
          <div className="flex flex-col gap-5 glass-card p-8 rounded-[4rem] shadow-[0_40px_80px_-15px_rgba(0,22,71,0.2)] border-2 border-white/80 transform transition-transform translate-z-0">
            {messages.length === 0 && (
              <div className="flex gap-4 animate-in fade-in slide-in-from-top-3 duration-500">
                <input
                  type="text"
                  value={inputTitle}
                  onChange={(e) => setInputTitle(e.target.value)}
                  placeholder="Nome do Sistema"
                  className="flex-1 px-8 py-5 rounded-3xl bg-brand-bege/60 border-2 border-transparent focus:border-brand-azul/40 text-[12px] font-black uppercase tracking-widest outline-none transition-all shadow-inner placeholder:text-brand-azulEscuro/20"
                />
                <input
                  type="text"
                  value={inputDescription}
                  onChange={(e) => setInputDescription(e.target.value)}
                  placeholder="Dialeto (ex: Oracle, Postgres, Python)"
                  className="flex-1 px-8 py-5 rounded-3xl bg-brand-bege/60 border-2 border-transparent focus:border-brand-azul/40 text-[12px] font-black uppercase tracking-widest outline-none transition-all shadow-inner placeholder:text-brand-azulEscuro/20"
                />
              </div>
            )}
            
            <div className="relative flex items-center bg-brand-bege/80 rounded-[2.5rem] p-3 border-2 border-brand-azulEscuro/5 shadow-inner group-focus-within:bg-white transition-colors">
              <div className="flex gap-2 ml-3">
                <button className="uiverse-input-btn scale-95" data-label="ANEXAR"><svg className="svgIcon" viewBox="0 0 24 24" fill="none"><path d="M12 15V3M12 3L8 7M12 3L16 7" stroke="white" strokeWidth="3" /><path d="M2 17L2.621 19.485C2.821 20.284 3.541 20.838 4.364 20.838H19.636C20.459 20.838 21.179 20.284 21.379 19.485L22 17" stroke="white" strokeWidth="3" /></svg></button>
                <button 
                  onClick={toggleListening}
                  className={`uiverse-input-btn btn-mic scale-95 transition-all duration-300 ${isListening ? 'bg-brand-coral animate-pulse shadow-[0_0_20px_rgba(230,78,54,0.5)]' : ''}`} 
                  data-label={isListening ? "OUVINDO..." : "ÁUDIO"}
                >
                  <svg className="svgIcon" viewBox="0 0 24 24" fill="none">
                    <rect x="9" y="2" width="6" height="11" rx="3" stroke="white" strokeWidth="3" />
                    <path d="M5 10V11C5 14.866 8.13401 18 12 18V18C15.866 18 19 14.866 19 11V10" stroke="white" strokeWidth="3" />
                    <line x1="12" y1="18" x2="12" y2="22" stroke="white" strokeWidth="3" />
                  </svg>
                </button>
              </div>
              <input
                type="text"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
                placeholder={isListening ? "Fale agora..." : "Qual lógica de dados precisamos estruturar?"}
                className={`flex-1 bg-transparent px-8 py-5 outline-none text-brand-azulEscuro text-lg font-bold placeholder:text-brand-azulEscuro/20 transition-all ${isListening ? 'opacity-50' : ''}`}
              />
              <button onClick={handleGenerate} disabled={isLoading} className="btn-animate w-16 h-16 mr-3">
                <svg className="w-8 h-8 z-10" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M5 12H19M19 12L13 6M19 12L13 18" stroke="white" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                <StarSVG className="star-1" /><StarSVG className="star-2" /><StarSVG className="star-3" /><StarSVG className="star-4" /><StarSVG className="star-5" /><StarSVG className="star-6" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className={`transition-all duration-700 ease-[cubic-bezier(0.34,1.56,0.64,1)] flex flex-col h-full overflow-visible ${isCanvasOpen ? 'w-1/2 translate-x-0 opacity-100 visible' : 'w-0 translate-x-32 opacity-0 invisible'}`}>
        {currentQuery && (
          <div className="flex-1 flex flex-col bg-brand-azulEscuro rounded-[4rem] shadow-[0_50px_100px_-20px_rgba(0,0,0,0.6)] overflow-hidden border-[10px] border-white/10 relative mb-12">
            
            <button 
              onClick={() => setIsCanvasOpen(false)}
              className="absolute top-10 right-10 z-50 p-5 bg-white/10 hover:bg-brand-azul text-white rounded-[2.5rem] transition-all shadow-2xl backdrop-blur-xl group flex items-center justify-center border-2 border-white/20 active:scale-90"
            >
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" className="group-hover:translate-x-1 transition-transform">
                <polyline points="9 18 15 12 9 6"></polyline>
              </svg>
            </button>

            <div className="p-16 pb-8 pt-20 flex flex-col">
              <div className="flex gap-4 mb-10">
                <span className="px-6 py-2.5 bg-brand-azul text-white text-[12px] font-black rounded-2xl uppercase tracking-[0.2em] border border-white/20 shadow-xl">{currentQuery.category}</span>
                <span className="px-6 py-2.5 bg-white/10 text-white text-[12px] font-black rounded-2xl uppercase tracking-[0.2em] border border-white/10 backdrop-blur-sm">{currentQuery.language}</span>
              </div>
              
              <div className="mb-4">
                {isEditingTitle ? (
                  <input 
                    autoFocus
                    value={editedTitle}
                    onChange={(e) => setEditedTitle(e.target.value)}
                    onBlur={() => setIsEditingTitle(false)}
                    onKeyDown={(e) => e.key === 'Enter' && setIsEditingTitle(false)}
                    className="w-full bg-white/5 text-5xl font-black text-white leading-tight tracking-tighter outline-none border-b-4 border-brand-azul transition-all pb-3 px-3 rounded-t-2xl"
                  />
                ) : (
                  <div 
                    className="flex items-center gap-5 group cursor-text"
                    onDoubleClick={() => setIsEditingTitle(true)}
                  >
                    <h2 className="text-5xl font-black text-white leading-tight tracking-tighter drop-shadow-xl truncate">
                      {editedTitle || currentQuery.title}
                    </h2>
                    <button 
                      onClick={() => setIsEditingTitle(true)}
                      className="p-2 rounded-xl bg-white/5 text-white/20 group-hover:text-white/80 group-hover:bg-brand-azul transition-all opacity-0 group-hover:opacity-100"
                    >
                      <ICONS.Edit className="w-6 h-6" />
                    </button>
                  </div>
                )}
              </div>

              <div className="mt-4">
                {isEditingDesc ? (
                  <textarea 
                    autoFocus
                    value={editedDescription}
                    onChange={(e) => setEditedDescription(e.target.value)}
                    onBlur={() => setIsEditingDesc(false)}
                    className="w-full bg-white/5 text-white/70 text-lg font-medium leading-relaxed max-w-2xl outline-none resize-none overflow-hidden h-auto focus:text-white transition-all p-4 rounded-2xl border-2 border-brand-azul/30"
                    rows={3}
                  />
                ) : (
                  <div 
                    className="flex items-start gap-4 group cursor-text"
                    onDoubleClick={() => setIsEditingDesc(true)}
                  >
                    <p className="text-white/70 text-lg font-medium leading-relaxed max-w-2xl">
                      {editedDescription || currentQuery.description}
                    </p>
                    <button 
                      onClick={() => setIsEditingDesc(true)}
                      className="p-2 rounded-xl bg-white/5 text-white/20 group-hover:text-white/80 group-hover:bg-brand-azul transition-all opacity-0 group-hover:opacity-100 shrink-0 mt-1"
                    >
                      <ICONS.Edit className="w-5 h-5" />
                    </button>
                  </div>
                )}
              </div>
            </div>

            <div className="flex-1 relative bg-black/50 m-12 mt-4 rounded-[4rem] overflow-hidden border-2 border-white/5 shadow-[inset_0_8px_40px_rgba(0,22,71,0.5)]">
              <div className="absolute top-10 left-12 flex gap-3.5 z-20">
                <div className="w-5 h-5 rounded-full bg-brand-coral/80 animate-pulse shadow-[0_0_15px_rgba(230,78,54,0.4)]"></div>
                <div className="w-5 h-5 rounded-full bg-brand-amarelo/80 shadow-[0_0_15px_rgba(240,160,40,0.4)]"></div>
                <div className="w-5 h-5 rounded-full bg-brand-verde/80 shadow-[0_0_15px_rgba(119,158,61,0.4)]"></div>
              </div>

              <div className="absolute top-8 right-12 flex gap-5 z-20">
                <button onClick={handleUndo} className="p-4 bg-white/10 hover:bg-white/20 text-white rounded-2xl transition-all border-2 border-white/10 shadow-2xl active:scale-90" title="Desfazer"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round"><path d="M3 7v6h6"/><path d="M21 17a9 9 0 0 0-9-9 9 9 0 0 0-6 2.3L3 13"/></svg></button>
                <button onClick={handleRedo} className="p-4 bg-white/10 hover:bg-white/20 text-white rounded-2xl transition-all border-2 border-white/10 shadow-2xl active:scale-90" title="Refazer"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round"><path d="M21 7v6h-6"/><path d="M3 17a9 9 0 0 1 9-9 9 9 0 0 1 6 2.3l3 2.7"/></svg></button>
              </div>

              <textarea
                value={editedCode}
                onChange={(e) => { setEditedCode(e.target.value); addToHistory(e.target.value); }}
                className="w-full h-full p-20 pt-32 bg-transparent text-white font-mono text-lg leading-relaxed resize-none outline-none selection:bg-brand-azul/40 custom-scrollbar"
                spellCheck={false}
              />
            </div>

            <div className="px-16 pt-8 pb-10 flex items-center justify-center bg-white/5 border-t border-white/5">
              <div className="flex items-center gap-10 p-5 px-14 rounded-[3rem] bg-black/60 border-2 border-white/10 shadow-[0_30px_60px_rgba(0,0,0,0.5)] backdrop-blur-3xl">
                
                <button 
                  onClick={handleCopy}
                  className={`uiverse-input-btn scale-125 transition-all duration-700 ${copyFeedback ? 'bg-brand-verde shadow-[0_0_30px_rgba(119,158,61,0.6)]' : ''}`}
                  data-label={copyFeedback ? "COPIADO!" : "COPIAR TUDO"}
                >
                  {copyFeedback ? (
                    <svg className="svgIcon animate-in zoom-in duration-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                  ) : (
                    <svg className="svgIcon" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
                  )}
                </button>

                <div className="w-px h-12 bg-white/10 mx-2"></div>
                
                <button 
                  onClick={handleSave}
                  className={`uiverse-input-btn scale-125 border-2 border-white/10 transition-all duration-700 ${saveFeedback ? 'bg-brand-verde' : 'bg-brand-azul hover:bg-brand-azulEscuro'}`}
                  data-label={saveFeedback ? "SALVO!" : "BIBLIOTECA"}
                >
                  {saveFeedback ? (
                    <svg className="svgIcon animate-in zoom-in duration-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                  ) : (
                    <ICONS.Plus className="svgIcon w-8 h-8" strokeWidth="5" />
                  )}
                </button>
                
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default QueryCanvas;
