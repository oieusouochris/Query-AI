
import React, { useState, useEffect, useRef } from 'react';
import { QueryRecord, Category } from '../types';
import { ICONS, CATEGORIES, COLORS } from '../constants';

interface QueryGalleryProps {
  queries: QueryRecord[];
  onClone?: (query: QueryRecord) => void;
  onUpdate?: (query: QueryRecord) => void;
  onDelete?: (id: string) => void;
  onEditInChat?: (query: QueryRecord) => void;
}

const REACTIONS = ['👏🏻', '🔥', '💡', '✅'];

const QueryGallery: React.FC<QueryGalleryProps> = ({ queries, onClone, onUpdate, onDelete, onEditInChat }) => {
  const [filter, setFilter] = useState<string>('Tudo');
  const [search, setSearch] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [activePickerId, setActivePickerId] = useState<string | null>(null);

  const gliderRef = useRef<HTMLSpanElement>(null);
  const tabsRef = useRef<{ [key: string]: HTMLLabelElement | null }>({});

  const allCategories = ['Tudo', ...CATEGORIES];

  const filteredQueries = queries.filter(q => {
    const matchesCategory = filter === 'Tudo' || q.category === filter;
    const matchesSearch = q.title.toLowerCase().includes(search.toLowerCase()) || 
                          q.description.toLowerCase().includes(search.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleCopy = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDownload = (query: QueryRecord) => {
    const blob = new Blob([query.code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${query.title.replace(/\s+/g, '_')}.sql`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleReaction = (query: QueryRecord, reaction: string) => {
    const counts = { ...(query.reactionCounts || {}) };
    let selectedReaction = query.selectedReaction;

    if (selectedReaction === reaction) {
      counts[reaction] = Math.max(0, (counts[reaction] || 1) - 1);
      selectedReaction = undefined;
    } else {
      if (selectedReaction) {
        counts[selectedReaction] = Math.max(0, (counts[selectedReaction] || 1) - 1);
      }
      counts[reaction] = (counts[reaction] || 0) + 1;
      selectedReaction = reaction;
    }

    onUpdate?.({ ...query, selectedReaction, reactionCounts: counts });
    setActivePickerId(null);
  };

  useEffect(() => {
    const activeRef = tabsRef.current[filter];
    if (activeRef && gliderRef.current) {
      gliderRef.current.style.width = `${activeRef.offsetWidth}px`;
      gliderRef.current.style.left = `${activeRef.offsetLeft}px`;
    }
  }, [filter]);

  // Handle outside click to close picker
  useEffect(() => {
    const handleClickOutside = () => setActivePickerId(null);
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  return (
    <div className="w-full pb-20 animate-in fade-in duration-700">
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between mb-12 gap-8 px-4">
        <div>
          <h2 className="text-4xl font-black text-brand-azulEscuro tracking-tight">Biblioteca Estruturada</h2>
          <p className="text-brand-azulEscuro/40 font-medium text-base">Seus ativos de dados organizados e avaliados.</p>
        </div>
        
        <div className="container-input" onClick={(e) => e.stopPropagation()}>
          <ICONS.Search className="w-5 h-5" />
          <input
            type="text"
            placeholder="O que você está procurando?"
            className="input-search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="flex mb-14 overflow-x-auto pb-4 scrollbar-hide px-4">
        <div className="tabs-container">
          {allCategories.map((cat, idx) => (
            <React.Fragment key={cat}>
              <input 
                type="radio" 
                id={`cat-radio-${idx}`} 
                name="cat-filter" 
                checked={filter === cat} 
                onChange={() => setFilter(cat)}
              />
              <label 
                ref={el => { tabsRef.current[cat] = el; }}
                className="tab-label" 
                htmlFor={`cat-radio-${idx}`}
              >
                {cat}
                {cat !== 'Tudo' && (
                  <span className="ml-2 opacity-40 text-[10px]">
                    {queries.filter(q => q.category === cat).length}
                  </span>
                )}
              </label>
            </React.Fragment>
          ))}
          <span ref={gliderRef} className="glider"></span>
        </div>
      </div>

      {filteredQueries.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-32 text-brand-azulEscuro/20">
          <ICONS.Collections className="w-16 h-16 mb-4" />
          <p className="text-xl font-bold">Nenhuma Query encontrada</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 px-4 max-w-7xl">
          {filteredQueries.map((q) => (
            <div 
              key={q.id} 
              className="bg-white rounded-[2.5rem] p-10 shadow-[0_15px_50px_-20px_rgba(0,0,0,0.08)] border border-brand-azulEscuro/5 hover:border-brand-azul/10 transition-all duration-300 flex flex-col relative"
            >
              <div className="flex items-start justify-between mb-8">
                <div className="w-10 h-10 bg-brand-coral/10 rounded-xl flex items-center justify-center">
                  <ICONS.Sparkles className="w-5 h-5 text-brand-coral" />
                </div>
                
                <div className="relative" onClick={(e) => e.stopPropagation()}>
                  <button 
                    onClick={() => setActivePickerId(activePickerId === q.id ? null : q.id)}
                    className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                      q.selectedReaction 
                      ? 'bg-brand-azul text-white' 
                      : 'bg-brand-bege text-brand-azulEscuro/20 hover:bg-brand-azul/10 hover:text-brand-azul border border-brand-azulEscuro/5'
                    }`}
                  >
                    <span className="text-base">{q.selectedReaction || '👏🏻'}</span>
                  </button>

                  {activePickerId === q.id && (
                    <div className="absolute top-full mt-2 right-0 bg-white shadow-2xl rounded-2xl p-2 flex gap-1 z-50 border border-brand-azulEscuro/5 animate-in fade-in slide-in-from-top-2 duration-200">
                      {REACTIONS.map((emoji) => (
                        <button 
                          key={emoji}
                          onClick={() => handleReaction(q, emoji)}
                          className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all hover:bg-brand-bege ${
                            q.selectedReaction === emoji ? 'bg-brand-azul/10 text-brand-azul' : 'text-xl'
                          }`}
                        >
                          <span className="text-base">{emoji}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <div className="mb-10">
                <p className="text-[10px] font-black text-brand-azulEscuro/30 uppercase tracking-[0.2em] mb-3">
                  {q.language} • {new Date(q.createdAt).toLocaleDateString('pt-BR')}
                </p>
                <h3 className="text-2xl font-black text-brand-azulEscuro leading-tight mb-4">
                  {q.title}
                </h3>
                <p className="text-brand-azulEscuro/50 text-[15px] font-medium leading-relaxed line-clamp-2">
                  {q.description}
                </p>
              </div>

              <div className="mt-auto pt-10 flex items-center justify-between border-t border-brand-azulEscuro/5">
                <div className="flex gap-3">
                  <button 
                    onClick={() => onDelete?.(q.id)}
                    className="w-10 h-10 bg-brand-bege hover:bg-brand-coral/10 rounded-full flex items-center justify-center text-brand-azulEscuro/30 hover:text-brand-coral transition-colors"
                  >
                    <ICONS.Trash className="w-5 h-5" />
                  </button>
                  <button 
                    onClick={() => handleDownload(q)}
                    className="w-10 h-10 bg-brand-bege hover:bg-brand-azul/10 rounded-full flex items-center justify-center text-brand-azulEscuro/30 hover:text-brand-azul transition-colors"
                  >
                    <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                  </button>
                </div>
                
                <div className="flex gap-4">
                  <button 
                    onClick={() => onEditInChat?.(q)}
                    className="px-8 py-3 bg-brand-bege hover:bg-brand-azulEscuro/5 text-brand-azulEscuro font-black text-[11px] rounded-2xl uppercase tracking-widest transition-all"
                  >
                    EDITAR
                  </button>

                  <button 
                    onClick={() => handleCopy(q.code, q.id)}
                    className={`px-8 py-3 flex items-center gap-2 font-black text-[11px] rounded-2xl uppercase tracking-widest transition-all shadow-xl ${
                      copiedId === q.id 
                      ? 'bg-brand-verde text-white shadow-brand-verde/20' 
                      : 'bg-brand-azul text-white shadow-brand-azul/30 hover:bg-brand-azulEscuro active:scale-95'
                    }`}
                  >
                    {copiedId === q.id ? (
                      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                    ) : (
                      <ICONS.Copy className="w-4 h-4" />
                    )}
                    COPIAR QUERY
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default QueryGallery;
