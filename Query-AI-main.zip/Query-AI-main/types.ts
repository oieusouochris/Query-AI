
export enum Category {
  REPORTS = 'Relatórios',
  QUERIES = 'Consultas',
  SPREADSHEETS = 'Planilhas',
  AUTOMATION = 'Automação',
  DASHBOARD = 'Dashboard'
}

export interface QueryRecord {
  id: string;
  title: string;
  description: string;
  code: string;
  category: Category;
  createdAt: string;
  language: string;
  rating?: number;
  selectedReaction?: string;
  reactionCounts?: Record<string, number>;
}

export interface AIResponse {
  title: string;
  description: string;
  code: string;
  category: string;
  language: string;
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  query?: AIResponse;
}

export interface ChatHistoryItem {
  id: string;
  prompt: string;
  response: AIResponse;
  messages: Message[];
  timestamp: string;
}
