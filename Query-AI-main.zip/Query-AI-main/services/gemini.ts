
import { GoogleGenAI, Type } from "@google/genai";
import { AIResponse } from "../types";

export const generateQuery = async (prompt: string): Promise<AIResponse> => {
  // Initialize right before making an API call to ensure it always uses the most up-to-date API key
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview", // Utilizando Pro para maior robustez e completude nas queries
      contents: `Você é um Engenheiro de Dados Sênior. Sua tarefa é criar uma consulta (query) de dados extremamente ROBUSTA, COMPLETA e PRONTA PARA PRODUÇÃO baseada neste pedido: "${prompt}".

Instruções Adicionais para Robustez:
1. Use melhores práticas de performance (índices, CTEs quando apropriado, filtros eficientes).
2. Trate casos de borda (NULLs, duplicatas) se aplicável ao contexto.
3. Inclua comentários breves e úteis dentro do código.
4. Garanta que a sintaxe esteja correta para a linguagem especificada.
5. Se o pedido for ambíguo, assuma a estrutura de dados mais lógica e profissional.

Responda exclusivamente em um formato JSON estruturado com textos em PORTUGUÊS.`,
      config: {
        thinkingConfig: {
          thinkingBudget: 16000 // Habilitando o pensamento profundo para garantir a qualidade da query
        },
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING, description: "Título curto e profissional da query" },
            description: { type: Type.STRING, description: "Explicação detalhada da lógica aplicada para garantir robustez" },
            code: { type: Type.STRING, description: "A string SQL ou código completo, formatado e comentado" },
            category: { type: Type.STRING, description: "Deve ser um destes: Relatórios, Consultas, Planilhas, Automação ou Dashboard" },
            language: { type: Type.STRING, description: "Linguagem utilizada (ex: SQL (PostgreSQL), Python (Pandas), Excel VBA)" }
          },
          required: ["title", "description", "code", "category", "language"],
          propertyOrdering: ["title", "description", "code", "category", "language"]
        }
      }
    });

    const result = JSON.parse(response.text.trim()) as AIResponse;
    return result;
  } catch (error: any) {
    console.error("Erro na API Gemini:", error);
    
    if (error.message?.includes('429') || error.message?.includes('RESOURCE_EXHAUSTED')) {
      throw new Error("Limite de requisições atingido. Por favor, aguarde um momento antes de tentar novamente ou use uma chave API com quota disponível.");
    }
    
    throw new Error("Falha ao gerar a consulta robusta. Por favor, tente novamente.");
  }
};
